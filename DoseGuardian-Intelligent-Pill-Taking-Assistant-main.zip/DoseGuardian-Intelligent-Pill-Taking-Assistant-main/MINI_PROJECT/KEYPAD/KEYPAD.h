void keypad_init(void);
int stat_key(void);
char keypad_data(void);
