#define LCD_DATA 0
#define RS 8
#define RW 9
#define EN 10

#define GOTO_LINE_1_POS_0 0x80
#define GOTO_LINE_2_POS_0 0xc0

#define LCD_CLR 0x01
